package org.firstinspires.ftc.teamcode.opModes.Auto.BLUE;

import static org.firstinspires.ftc.teamcode.subsystems.DriveTrain2.servoOffset;
import static org.firstinspires.ftc.teamcode.subsystems.ShooterCalc.calculateShotVectorandUpdateHeading;
import static org.firstinspires.ftc.teamcode.subsystems.DriveTrain2.closeStopperPos;
import static org.firstinspires.ftc.teamcode.subsystems.DriveTrain2.openStopperPos;
import static org.firstinspires.ftc.teamcode.subsystems.Flywheel.shooter;
import static org.firstinspires.ftc.teamcode.subsystems.LaunchDetector.isOverlappingLaunchZone;

import com.bylazar.configurables.annotations.Configurable;
import com.pedropathing.follower.Follower;
import com.pedropathing.geometry.BezierCurve;
import com.pedropathing.geometry.BezierLine;
import com.pedropathing.geometry.Pose;
import com.pedropathing.math.Vector;
import com.pedropathing.paths.PathChain;
import com.pedropathing.util.Timer;
import com.qualcomm.hardware.lynx.LynxModule;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.hardware.PwmControl;
import com.qualcomm.robotcore.hardware.ServoImplEx;

import org.firstinspires.ftc.teamcode.pedroPathing.Constants;
import org.firstinspires.ftc.teamcode.subsystems.Storage;

import java.util.List;

import dev.nextftc.core.commands.Command;
import dev.nextftc.core.commands.delays.Delay;
import dev.nextftc.core.commands.groups.SequentialGroup;
import dev.nextftc.core.commands.utility.LambdaCommand;
import dev.nextftc.core.components.BindingsComponent;
import dev.nextftc.extensions.pedro.FollowPath;
import dev.nextftc.extensions.pedro.PedroComponent;
import dev.nextftc.ftc.ActiveOpMode;
import dev.nextftc.ftc.NextFTCOpMode;
import dev.nextftc.ftc.components.BulkReadComponent;
import dev.nextftc.hardware.impl.MotorEx;
import dev.nextftc.hardware.impl.ServoEx;

@Disabled
@Autonomous(name = "Blue Near 24 V1")
@Configurable
public class blue24Near extends NextFTCOpMode {

    public blue24Near() {
        addComponents(
                BulkReadComponent.INSTANCE,
                BindingsComponent.INSTANCE,
                new PedroComponent(hwMap -> Constants.createFollower(hwMap))
        );
    }

    private Follower follower;
    private MotorEx transfer;
    private Timer opmodeTimer;
    private Paths paths;

    public static double startX = 34.83;
    public static double startY = 134.4;

    public Pose start = new Pose(startX, startY, Math.toRadians(270));

    // --- Turret tracking ---
    private ServoEx servoStopper;
    private ServoEx hoodServo;

    double goalY = 140;
    double goalX = 1;

    public static double gateX = 12; // 142 - 11.8
    public static double gateY = 60;

    public static double gateX2 = 10.5; // 142 - 11.2
    public static double gateY2 = 61;

    public static double PivotPoseX = 110;

    public static double PivotPoseY = 70;

    public static double controlX = 7;

    public static double controlY = -4.5;

    public static double launchX = 80.7613;
    public static double launchY = 87.9072;

    public static double gateHeading = 154;

    public static double gateX1 = 10.5; // 142 - 10.5
    public static double gateY1 = 59;


    public static double gateHeading1 = 154;

    private static final double MIN_ANGLE = -224.75;
    private static final double MAX_ANGLE = 224.75;
    private static final double TURRET_RANGE = 449.51;

    private double currentTurretPos = 90;

    public static double turretHeading4 = -140;

    private boolean matchStarted = false;
    private boolean autoShoot = false;
    private boolean useAutoGoalTracking = true;


    private boolean isOverridden = false;
    private double overriddenTurretAngle;

    private MotorEx intakeMotor;
    private ServoImplEx turret1;
    private ServoImplEx turret2;

    public static double turretOffset = 10;
    public static double turretOffset2 = 2;
    public static double turretOffsetStep = -5;

    // Inches from the Pinpoint/Pedro robot pose origin to the turret pivot.
    public static double turretForwardOffset = -0.52588;
    public static double turretStrafeOffset = 0;

    private Command intakeMotorOn = new LambdaCommand()
            .setStart(() -> {
                intakeMotor.setPower(1);
                transfer.setPower(1);
            });


    private Command intakeMotorOff = new LambdaCommand()
            .setStart(() -> {
                intakeMotor.setPower(0);
                transfer.setPower(0);
            });

    private List<LynxModule> allHubs;
    public Pose currPose;

    public double getClosestValidTurretAngle(double relativeGoalDegrees) {
        double option1 = normalizeDegrees(relativeGoalDegrees);
        return Math.max(MIN_ANGLE, Math.min(MAX_ANGLE, option1));
    }

    private double normalizeDegrees(double degrees) {
        while (degrees > 180.0) {
            degrees -= 360.0;
        }
        while (degrees <= -180.0) {
            degrees += 360.0;
        }
        return degrees;
    }

    private Pose getTurretPose(Pose robotPose) {
        double heading = robotPose.getHeading();

        double cos = Math.cos(heading);
        double sin = Math.sin(heading);

        double turretX = robotPose.getX()
                + turretForwardOffset * cos
                - turretStrafeOffset * sin;


        double turretY = robotPose.getY()
                + turretForwardOffset * sin
                + turretStrafeOffset * cos;

        return new Pose(turretX, turretY, heading);
    }

    private Vector getTurretToGoalVector(Pose turretPose) {
        return new Vector(
                turretPose.distanceFrom(new Pose(goalX, goalY)),
                Math.atan2(goalY - turretPose.getY(), goalX - turretPose.getX())
        );
    }

    //public SequentialGroup shoot = new SequentialGroup(
    //servoOpen,
    //new Delay(0.3)
    //servoClose
    //);

    double targetTurretAngle;


    public boolean manualTPS = true;


    public Command autoShootEnable() {
        return new LambdaCommand()
                .setStart(() -> autoShoot = true);
    }

    // --- Custom Override Tracking Commands ---
    public Command setTurretHeading(double degrees) {
        return new LambdaCommand("Set Turret Heading: " + degrees)
                .setStart(() -> {
                    isOverridden = true;
                    overriddenTurretAngle = getClosestValidTurretAngle(degrees);
                })
                .setIsDone(() -> true);
    }

    /*public Command enableGoalTracking() {
        return new LambdaCommand("Enable Goal Tracking")
                .setStart(() -> {
                    isOverridden = false;
                })
                .setIsDone(() -> true);
    }*/

    public static MotorEx flywheel = new MotorEx("launchingmotor");

    public static MotorEx flywheel2 = new MotorEx("launchingmotor2");

    // ----------------------

    @Override
    public void onInit() {

        allHubs = ActiveOpMode.hardwareMap().getAll(LynxModule.class);

        for (LynxModule hub : allHubs) {
            hub.setBulkCachingMode(LynxModule.BulkCachingMode.MANUAL);
        }

        follower = PedroComponent.follower();

        follower.setStartingPose(start);

        paths = new Paths(follower);

        opmodeTimer = new Timer();

        intakeMotor = new MotorEx("intakeMotor");
        transfer = new MotorEx("transferMotor");

        turret1 = ActiveOpMode.hardwareMap().get(
                ServoImplEx.class,
                "turretServo1");

        turret2 = ActiveOpMode.hardwareMap().get(
                ServoImplEx.class,
                "turretServo2");

        turret1.setPwmRange(new PwmControl.PwmRange(500, 2500));
        turret2.setPwmRange(new PwmControl.PwmRange(500, 2500));
        hoodServo = new ServoEx("hoodServo");

        servoStopper = new ServoEx("stopperServo");

        isOverridden = true;
        preload = true;


        overriddenTurretAngle = getClosestValidTurretAngle(-160);
        double hoodAngle = 0.4;
        hoodServo.setPosition(hoodAngle);
        servoStopper.setPosition(closeStopperPos);
        double robotAngularVelocityRads = follower.getAngularVelocity();
        double robotAngularVelocityDegs = Math.toDegrees(robotAngularVelocityRads);
        double feedforwardOffset = 0;

        targetTurretAngle = getClosestValidTurretAngle(overriddenTurretAngle + turretOffset - feedforwardOffset);
        double servoPositionSignal = 0.05 + ((targetTurretAngle - MIN_ANGLE) / 449.51) * 0.90;
        servoPositionSignal = Math.max(0.05, Math.min(0.95, servoPositionSignal));

        turret1.setPosition(servoPositionSignal + servoOffset);
        turret2.setPosition(servoPositionSignal - servoOffset);
        double lastServoPos = servoPositionSignal;


        currentTurretPos = targetTurretAngle;
        //enableGoalTracking();


        telemetry.addLine("Initialized");
        telemetry.update();

        //setTurretHeading(turretHeading1).schedule();


        telemetry.addLine("Initialized");
        telemetry.update();
    }

    public Command closeStopper = new LambdaCommand()
            .setStart(() -> {
                servoStopper.setPosition(closeStopperPos); // close
            }).setIsDone(() -> true);
    public Command openStopper = new LambdaCommand()
            .setStart(() -> {
                servoStopper.setPosition(openStopperPos); // open
            }).setIsDone(() -> true);

    public Command Pivot = new LambdaCommand()
            .setStart(() -> {
                follower.turnTo(Math.toRadians(40));
            }).setIsDone(() -> true);

    public Command enableGoalTracking() {
        return new LambdaCommand("Enable Goal Tracking")
                .setStart(() -> {
                    isOverridden = false;
                })
                .setIsDone(() -> true);
    }


    public Command Auto() {
        return new SequentialGroup(

                setTurretHeading(overriddenTurretAngle),
                new Delay(0.3),

                new FollowPath(paths.Preload, false, 1.0),

                intakeMotorOn,
                openStopper,
                new Delay(0.2),
                closeStopper,
                disablePreload,

                //autoShootEnable(),

                new FollowPath(paths.Spike2, false, 1.0),
                new FollowPath(paths.launchspike2, false, 1.0),
                new FollowPath(paths.gateIntake1, true, 1.0),
                new FollowPath(paths.Pivot, true, 1.0),
                new Delay(1.05),
                new FollowPath(paths.gateIntake1Launch, false, 1.0),

                new FollowPath(paths.Path6, true, 1.0),
                new Delay(2.25),
                new FollowPath(paths.Path7, false, 1.0),

                new FollowPath(paths.Path8, true, 1.0),

                new Delay(2.25),

                new FollowPath(paths.Path9, false, 1.0),

                new FollowPath(paths.Path14, false, 1.0),
                intakeMotorOff,
                new FollowPath(paths.Path15, false, 1.0),
                intakeMotorOn,
                new FollowPath(paths.Path10, true, 1.0),
                //new FollowPath(paths.Pivot2,false,1.0),
                new Delay(1.05),
                new FollowPath(paths.Path11, false, 1.0),
                new FollowPath(paths.Path12, true, 1.0),
                new Delay(2.25),
                new FollowPath(paths.Path13, false, 1.0) //prk
        );
    }


    public void onStartButtonPressed() {
        opmodeTimer.resetTimer();
        matchStarted = true;
        Auto().schedule();
    }

    private boolean preload = true;

    public Command disablePreload = new LambdaCommand()
            .setStart(() -> preload = false);
    private double flywheelSpeed;


    @Override
    public void onUpdate() {

        for (LynxModule hub : allHubs) {
            hub.clearBulkCache();
        }

        follower.update();

        Storage.currentPose = follower.getPose();

        if (!matchStarted) return;

        Pose currPose = follower.getPose();

        Pose turretPose = getTurretPose(currPose);

        double robotHeading = follower.getPose().getHeading();

        Vector robotToGoalVector = getTurretToGoalVector(turretPose);

        Double[] results = calculateShotVectorandUpdateHeading(
                robotHeading,
                robotToGoalVector,
                follower.getVelocity().times(1.0), 1.25);

        flywheelSpeed = results[0];

        if (preload == true) {
            double hoodAngle = results[1];
            hoodServo.setPosition(hoodAngle);
            shooter((float) flywheelSpeed + 30);
            double robotAngularVelocityRads = follower.getAngularVelocity();
            double robotAngularVelocityDegs = Math.toDegrees(robotAngularVelocityRads);
            double feedforwardOffset = 0;

            targetTurretAngle = getClosestValidTurretAngle(overriddenTurretAngle - turretOffset - feedforwardOffset);
            double servoPositionSignal = 0.05 + ((targetTurretAngle - MIN_ANGLE) / 449.51) * 0.90;
            servoPositionSignal = Math.max(0.05, Math.min(0.95, servoPositionSignal));

            turret1.setPosition(servoPositionSignal + servoOffset);
            turret2.setPosition(servoPositionSignal - servoOffset);
            double lastServoPos = servoPositionSignal;


            currentTurretPos = targetTurretAngle;


        }

        if (preload == false) {
            shooter((float) flywheelSpeed);
            double hoodAngle = results[1];
            hoodServo.setPosition(hoodAngle);
            double headingError = results[2];
            double robotAngularVelocityRads = follower.getAngularVelocity();
            double robotAngularVelocityDegs = Math.toDegrees(robotAngularVelocityRads);
            double feedforwardOffset = robotAngularVelocityDegs * 0.225;
            targetTurretAngle = getClosestValidTurretAngle(headingError - turretOffset - feedforwardOffset);
            double servoPositionSignal = 0.05 + ((targetTurretAngle - MIN_ANGLE) / 449.51) * 0.90;
            servoPositionSignal = Math.max(0.05, Math.min(0.95, servoPositionSignal));

            turret1.setPosition(servoPositionSignal + servoOffset);
            turret2.setPosition(servoPositionSignal - servoOffset);

            currentTurretPos = targetTurretAngle;
        }


        Pose futurepose = new Pose(follower.getPose().getX() + (follower.getVelocity().getXComponent() * 0.25), follower.getPose().getY() + (follower.getVelocity().getYComponent() * 0.25), follower.getHeading());

        if (isOverlappingLaunchZone(futurepose) && robotToGoalVector.getMagnitude() > 45) {
            intakeMotor.setPower(1);
            transfer.setPower(1);
            openStopper.schedule();
        } else {
            closeStopper.schedule();
        }

        Storage.currentPose = follower.getPose();

        Storage.setPose = true;
    }

    @Override
    public void onStop() {
        Storage.currentPose = follower.getPose();
        follower.breakFollowing();
    }

    public class Paths {


        //dih
        public PathChain Preload;
        public PathChain Spike2;
        public PathChain launchspike2;
        public PathChain gateIntake1;

        public PathChain gateIntake1Launch;
        public PathChain Path6;
        public PathChain Path7;
        public PathChain Path8;
        public PathChain Path9;
        public PathChain Path10;

        public PathChain Pivot2;
        public PathChain Path11;
        public PathChain Path12;
        public PathChain Path13;
        public PathChain Path14;
        public PathChain Path15;
        public PathChain Pivot;

        public Paths(Follower follower) {

            Preload = follower.pathBuilder()
                    .addPath(new BezierLine(
                            new Pose(startX, startY),
                            new Pose(49.495, 94.650)))
                    .setLinearHeadingInterpolation(
                            Math.toRadians(270),
                            Math.toRadians(-60))
                    .build();

            Spike2 = follower.pathBuilder()
                    .addPath(new BezierCurve(
                            new Pose(49.495, 94.650),
                            new Pose(51.02, 59.7),
                            new Pose(19, 59.5)))
                    .setLinearHeadingInterpolation(
                            Math.toRadians(-60),
                            Math.toRadians(160))
                    .build();

            launchspike2 = follower.pathBuilder().addPath(
                            new BezierLine(
                                    new Pose(19, 59.5),
                                    new Pose(63.646, 69.703)
                            )
                    ).setLinearHeadingInterpolation(Math.toRadians(160), Math.toRadians(180))
                    .setVelocityConstraint(1.0)
                    .setTValueConstraint(0.8)


                    .build();

            gateIntake1 = follower.pathBuilder()
                    .addPath(new BezierLine(
                            new Pose(63.646, 69.703),
                            new Pose(14.5, 61.5)))
                    .setLinearHeadingInterpolation(
                            Math.toRadians(180), Math.toRadians(175))
                    .build();

            Pivot = follower.pathBuilder()
                    .addPath(new BezierLine(
                            new Pose(14.5, 61.5),
                            new Pose(14.2, 61.5)))
                    .setLinearHeadingInterpolation(
                            Math.toRadians(175),
                            Math.toRadians(gateHeading1))
                    .build();

            gateIntake1Launch = follower.pathBuilder()
                    .addPath(new BezierLine(
                            new Pose(10.8, 61.3),
                            new Pose(62.442, 73.32)))
                    .setLinearHeadingInterpolation(
                            Math.toRadians(gateHeading),
                            Math.toRadians(-165))
                    .build();

            Path6 = follower.pathBuilder()
                    .addPath(new BezierLine(
                            new Pose(61.942, 73.32),
                            new Pose(142 - gateX, gateY - 0.5)))
                    .setLinearHeadingInterpolation(
                            Math.toRadians(-165),
                            Math.toRadians(gateHeading))
                    .build();

            Path7 = follower.pathBuilder()
                    .addPath(new BezierLine(
                            new Pose(142 - gateX, gateY - 0.5),
                            new Pose(62.442, 75)))
                    .setLinearHeadingInterpolation(
                            Math.toRadians(gateHeading),
                            Math.toRadians(-165))
                    .build();

            Path8 = follower.pathBuilder()
                    .addPath(new BezierLine(
                            new Pose(62.442, 75),
                            new Pose(142 - gateX, gateY)))
                    .setLinearHeadingInterpolation(
                            Math.toRadians(-165),
                            Math.toRadians(gateHeading))
                    .build();

            Path9 = follower.pathBuilder()
                    .addPath(new BezierLine(
                            new Pose(142 - gateX, gateY),
                            new Pose(62.442, 75)))
                    .setLinearHeadingInterpolation(
                            Math.toRadians( gateHeading),
                            Math.toRadians(-165))
                    .build();

            Path10 = follower.pathBuilder()
                    .addPath(new BezierCurve(
                            new Pose(49.5330403761, 83.71111297536585),
                            new Pose(41.481, 63.28),
                            new Pose(142 - (gateX2 - 1), 142 - (gateY2 - 1))))
                    .setLinearHeadingInterpolation(
                            Math.toRadians(-165),
                            Math.toRadians(gateHeading - 5))
                    .build();

            Path11 = follower.pathBuilder()
                    .addPath(new BezierLine(
                            new Pose(142 - (gateX2 - 1), 142 - (gateY2 - 1)),
                            new Pose(60.5, 104.0)))
                    .setLinearHeadingInterpolation(
                            Math.toRadians(gateHeading - 5),
                            Math.toRadians(145))
                    //toRed(215))
                    .build();

            Path12 = follower.pathBuilder()
                    .addPath(new BezierCurve(
                            new Pose(48.69, 92),
                            new Pose(35.586, 66.749),
                            new Pose(142 - (gateX2 - 2), 142 - gateY2)))
                    .setLinearHeadingInterpolation(
                            Math.toRadians(145),
                            Math.toRadians(gateHeading - 5))
                    .build();

            Path13 = follower.pathBuilder()
                    .addPath(new BezierCurve(
                            new Pose(142 - (gateX2 - 2), 142 - gateY2),
                            new Pose(23, 52),
                            new Pose(60.5, 104.0)))
                    .setLinearHeadingInterpolation(
                            Math.toRadians(gateHeading - 5),
                            Math.toRadians(90))
                    .build();

            Path14 = follower.pathBuilder()
                    .addPath(new BezierCurve(
                            new Pose(62.442, 75),
                            new Pose(56.6913314961, 79.2375828716257),
                            new Pose(20.5, 83.8)))
                    .setLinearHeadingInterpolation(
                            Math.toRadians(-165),
                            Math.toRadians(180))
                    .build();

            Path15 = follower.pathBuilder()
                    .addPath(new BezierLine(
                            new Pose(23.5, 83.8),
                            new Pose(49.5330403761, 83.71111297536585)))
                    .setConstantHeadingInterpolation(
                            Math.toRadians(180))
                    .build();
        }
    }
}